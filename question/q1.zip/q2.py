lst=[1,7,8,5,13,4,6,11,9,3,10]
list=sorted(lst)
print(list[len(list)-2])
