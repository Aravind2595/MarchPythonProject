for i in range(1,7):
       for j in range(i,7-1):
           print('', end=" ")
       for k in range(0,i):
           print('*',end=" ")
       print()
